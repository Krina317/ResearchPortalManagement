package com.nirma.portal.portal_backend.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NuFundedProjectResponseDTO {
    private Long id;
    private String projectTitle;
    private String principalInvestigator;
    private String coPrincipalInvestigatorList;
    private Long amount;
    private String nuProjectCategory;
    private Double duration;
    private String academicYear;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String outcomeOfProject;
    private String publishedPaperDetails;
    private String jointPublicationProof;
    private String ugStudentDetailList;
    private String remarks;
    private LocalDate sanctionedDate;
    private String fundReceived;
}