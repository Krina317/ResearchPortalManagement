package com.nirma.portal.portal_backend.dto;

import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BookChapterRequestDTO {

    @NotNull
    private Long sourceId;

    @NotBlank
    private String bookTitle;

    @NotBlank
    private String bookChapterTitle;

    @NotBlank
    private String instituteName;

    @NotBlank
    private String deptName;

    private String nameOfBookPublisher;
    private Integer month;
    private Integer year;
    private String yearOfPublication;
    private String isbnNo;
    private String fileName;
    private String publicationType;
    private String publicationCity;

    /** Ordered author names; position = index + 1. May be empty, but not missing. */
    @NotNull
    private List<String> authors;
}