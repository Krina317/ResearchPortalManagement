package com.nirma.portal.portal_backend.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(AuthorRecordNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleAuthorRecordNotFound(
            AuthorRecordNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    } 
	
    @ExceptionHandler(ConferencePaperNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleConferencePaperNotFound(
            ConferencePaperNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DepartmentNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleDepartmentNotFound(
            DepartmentNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ExcelColumnMapNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleExcelColumnMapNotFound(
            ExcelColumnMapNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DuplicateConferencePaperException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateConferencePaper(
            DuplicateConferencePaperException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(NuFundedProjectNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNuFundedProjectNotFound(
            NuFundedProjectNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DuplicateNuFundedProjectException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateNuFundedProject(
            DuplicateNuFundedProjectException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }
    
    @ExceptionHandler(DuplicateExternalFundedProjectException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateExternalFundedProject(DuplicateExternalFundedProjectException ex){
    	ErrorResponse error = new ErrorResponse(HttpStatus.CONFLICT.value(), ex.getMessage(),LocalDateTime.now());
    	return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }
    
    @ExceptionHandler(ExternalFundedProjectNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleExternalFundedProjectNotFound(ExternalFundedProjectNotFoundException ex){
    	ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage(), LocalDateTime.now());
    	return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(BookChapterNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleBookChapterNotFound(
            BookChapterNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DuplicateBookChapterException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateBookChapter(
            DuplicateBookChapterException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgument(IllegalArgumentException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(DuplicateJournalPaperException.class)
    public ResponseEntity<ErrorResponse> handleDuplicateJournalPaper(
            DuplicateJournalPaperException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.CONFLICT);
    }
    @ExceptionHandler(PublicationAuthorNotFoundException.class)
    public ResponseEntity<ErrorResponse> handlePublicationAuthorNotFound(
            PublicationAuthorNotFoundException ex) {

        ErrorResponse error = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage(),
                LocalDateTime.now()
        );

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
}